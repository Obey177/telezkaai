---
name: rabbit-message-by-id
description: Ищет сообщение по message ID в локальной выгрузке или в RabbitMQ и выводит его description. Используй при разборе очередей, когда человек называет очередь и идентификатор сообщения.
---

# Сообщение RabbitMQ по ID

## Проверка окружения

Перед запуском проверь .NET SDK:

```bash
dotnet --version
```

Ожидается версия `10.x`. Если установлена только более старая версия, остановись и сообщи пользователю, что нужен .NET 10 SDK.

## Безопасный режим по умолчанию

Для обычной демонстрации работай с локальной копией сообщений. Брокер при этом не затрагивается:

```bash
dotnet run --project .agents/skills/rabbit-message-by-id/scripts/RabbitMessageTools.csproj -- \
  find \
  --source mock \
  --file data/rabbit_messages.jsonl \
  --queue order.events \
  --id MSG-7F31A9
```

Верни `queue`, `message_id`, `routing_key` и `description`.

## Локальный RabbitMQ через Compose

Запусти брокер:

```bash
docker compose up -d --wait rabbitmq
```

Опубликуй демонстрационные сообщения C#-утилитой:

```bash
dotnet run --project .agents/skills/rabbit-message-by-id/scripts/RabbitMessageTools.csproj -- \
  seed --file data/rabbit_messages.jsonl --exchange codex.demo --purge
```

После явного подтверждения пользователя можно выполнить ограниченный live-просмотр:

```bash
dotnet run --project .agents/skills/rabbit-message-by-id/scripts/RabbitMessageTools.csproj -- \
  find --source live --yes-live \
  --queue order.events --id MSG-7F31A9 --count 20
```

Перед live-режимом прочитай `references/rabbitmq_notes.md`.

Live-команда обязана использовать `ack_requeue_true`. Это означает, что полученные для диагностики сообщения возвращаются в очередь, а не подтверждаются с удалением. Утилита дополнительно выводит количество сообщений до и после просмотра. На локальном стенде без других потребителей эти значения должны совпадать.

## Правила ответа

- Не утверждай, что сообщения нет во всей очереди, если просмотрены только первые `count` сообщений.
- Сообщай, сколько сообщений просмотрено.
- Сообщай, что сообщения возвращены в очередь, и показывай счётчики до и после live-просмотра.
- Если на локальном стенде счётчик после просмотра меньше исходного, не объявляй проверку успешной: покажи предупреждение и предложи повторить её без других потребителей.
- Никогда не заменяй `ack_requeue_true` на `ack_requeue_false` или `reject_requeue_false`: эти режимы удалят полученные сообщения.
- Не выводи весь payload, если человеку нужен только `description`.
- Не используй live-режим в производственной очереди без разрешения владельца системы.
