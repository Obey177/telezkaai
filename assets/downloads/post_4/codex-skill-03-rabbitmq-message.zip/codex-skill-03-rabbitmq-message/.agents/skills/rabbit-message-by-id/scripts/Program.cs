using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace CodexSkillsDemo.RabbitMessageTools;

internal static class Program
{
    private static readonly JsonSerializerOptions PrettyJson = new()
    {
        WriteIndented = true,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    };

    private static readonly JsonSerializerOptions CompactJson = new()
    {
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    };

    public static async Task<int> Main(string[] args)
    {
        try
        {
            if (args.Length == 0)
            {
                PrintUsage();
                return 1;
            }

            var command = args[0].ToLowerInvariant();
            var options = CommandLineOptions.Parse(args.Skip(1).ToArray());
            return command switch
            {
                "find" => await FindAsync(options),
                "seed" => await SeedAsync(options),
                _ => throw new ArgumentException($"Неизвестная команда: {command}. Используйте find или seed."),
            };
        }
        catch (Exception exception)
        {
            Console.Error.WriteLine($"Ошибка: {exception.Message}");
            return 1;
        }
    }

    private static async Task<int> FindAsync(CommandLineOptions options)
    {
        var source = options.Get("source", "mock").ToLowerInvariant();
        var queue = options.Required("queue");
        var messageId = options.Required("id");
        var asJson = options.HasFlag("json");

        MessageLoadResult loadResult = source switch
        {
            "mock" => new MessageLoadResult(
                await LoadMockAsync(options.Get("file", "data/rabbit_messages.jsonl"), queue),
                MessagesRequeued: false,
                QueueMessagesBefore: null,
                QueueMessagesAfter: null),
            "live" => await LoadLiveAsync(options, queue),
            _ => throw new ArgumentException("Параметр --source должен быть mock или live."),
        };

        var messages = loadResult.Messages;
        var found = messages.FirstOrDefault(message => CandidateIds(message).Contains(messageId));
        if (found is null)
        {
            Console.WriteLine($"Сообщение {messageId} не найдено среди {messages.Count} просмотренных сообщений очереди {queue}.");
            PrintPreservationStatus(loadResult);
            return 2;
        }

        if (asJson)
        {
            var result = new JsonObject
            {
                ["queue"] = queue,
                ["message_id"] = messageId,
                ["routing_key"] = found.RoutingKey,
                ["description"] = DescriptionOf(found),
                ["inspected_count"] = messages.Count,
                ["messages_requeued"] = loadResult.MessagesRequeued,
                ["queue_messages_before"] = loadResult.QueueMessagesBefore is { } before
                    ? JsonValue.Create(before)
                    : null,
                ["queue_messages_after"] = loadResult.QueueMessagesAfter is { } after
                    ? JsonValue.Create(after)
                    : null,
                ["payload"] = found.Payload is null ? null : CloneNode(found.Payload),
            };
            Console.WriteLine(result.ToJsonString(PrettyJson));
        }
        else
        {
            Console.WriteLine($"Очередь:      {queue}");
            Console.WriteLine($"Message ID:   {messageId}");
            Console.WriteLine($"Routing key:  {found.RoutingKey ?? "—"}");
            Console.WriteLine($"Description:  {DescriptionOf(found)}");
            Console.WriteLine($"Просмотрено:  {messages.Count}");
            PrintPreservationStatus(loadResult);
        }

        return 0;
    }

    private static async Task<IReadOnlyList<MessageEnvelope>> LoadMockAsync(string path, string queue)
    {
        if (!File.Exists(path))
        {
            throw new FileNotFoundException($"Не найден файл сообщений: {path}", path);
        }

        var messages = new List<MessageEnvelope>();
        var lineNumber = 0;
        foreach (var line in await File.ReadAllLinesAsync(path, Encoding.UTF8))
        {
            lineNumber++;
            if (string.IsNullOrWhiteSpace(line))
            {
                continue;
            }

            JsonObject item;
            try
            {
                item = JsonNode.Parse(line) as JsonObject
                    ?? throw new JsonException("Ожидался JSON-объект.");
            }
            catch (JsonException exception)
            {
                throw new InvalidDataException($"Некорректный JSON в строке {lineNumber}: {exception.Message}", exception);
            }

            if (!string.Equals(GetString(item["queue"]), queue, StringComparison.Ordinal))
            {
                continue;
            }

            messages.Add(new MessageEnvelope(
                queue,
                GetString(item["message_id"]),
                GetString(item["routing_key"]),
                item["headers"] as JsonObject ?? new JsonObject(),
                item["payload"]));
        }

        return messages;
    }

    private static async Task<MessageLoadResult> LoadLiveAsync(
        CommandLineOptions options,
        string queue)
    {
        if (!options.HasFlag("yes-live"))
        {
            throw new ArgumentException("Для live-режима добавьте --yes-live: просмотр получает и ставит сообщения обратно в очередь.");
        }

        var count = options.GetInt("count", 100);
        if (count is < 1 or > 500)
        {
            throw new ArgumentOutOfRangeException(nameof(count), "--count должен быть от 1 до 500.");
        }

        Console.Error.WriteLine("ВНИМАНИЕ: live-режим получает сообщения через Management API и возвращает их в очередь.");

        using var client = CreateRabbitClient(options);
        var queueMessagesBefore = await GetQueueMessageCountAsync(client, options, queue);
        var url = BuildQueueUrl(options, queue) + "/get";
        var request = new JsonObject
        {
            ["count"] = count,
            ["ackmode"] = "ack_requeue_true",
            ["encoding"] = "auto",
            ["truncate"] = 100_000,
        };

        var responseNode = await SendJsonAsync(client, HttpMethod.Post, url, request);
        var response = responseNode as JsonArray
            ?? throw new InvalidDataException("RabbitMQ вернул неожиданный ответ: ожидался JSON-массив.");

        var messages = new List<MessageEnvelope>();
        foreach (var node in response)
        {
            if (node is not JsonObject item)
            {
                continue;
            }

            var properties = item["properties"] as JsonObject ?? new JsonObject();
            var headers = properties["headers"] as JsonObject ?? new JsonObject();
            messages.Add(new MessageEnvelope(
                queue,
                GetString(properties["message_id"]),
                GetString(item["routing_key"]),
                headers,
                DecodeApiPayload(item)));
        }

        var queueMessagesAfter = await WaitForQueueMessageCountAsync(
            client,
            options,
            queue,
            queueMessagesBefore);

        if (queueMessagesBefore is { } before
            && queueMessagesAfter is { } after
            && after < before)
        {
            Console.Error.WriteLine(
                $"ПРЕДУПРЕЖДЕНИЕ: после requeue в очереди видно меньше сообщений: до {before}, после {after}. " +
                "В локальном стенде без других потребителей значения должны совпадать.");
        }

        return new MessageLoadResult(
            messages,
            MessagesRequeued: true,
            QueueMessagesBefore: queueMessagesBefore,
            QueueMessagesAfter: queueMessagesAfter);
    }

    private static async Task<int> SeedAsync(CommandLineOptions options)
    {
        var path = options.Get("file", "data/rabbit_messages.jsonl");
        if (!File.Exists(path))
        {
            throw new FileNotFoundException($"Не найден файл сообщений: {path}", path);
        }

        var messages = new List<MessageEnvelope>();
        var lineNumber = 0;
        foreach (var line in await File.ReadAllLinesAsync(path, Encoding.UTF8))
        {
            lineNumber++;
            if (string.IsNullOrWhiteSpace(line))
            {
                continue;
            }

            var item = JsonNode.Parse(line) as JsonObject
                ?? throw new InvalidDataException($"Строка {lineNumber}: ожидался JSON-объект.");
            var queue = GetString(item["queue"])
                ?? throw new InvalidDataException($"Строка {lineNumber}: отсутствует queue.");
            var messageId = GetString(item["message_id"])
                ?? throw new InvalidDataException($"Строка {lineNumber}: отсутствует message_id.");
            messages.Add(new MessageEnvelope(
                queue,
                messageId,
                GetString(item["routing_key"]),
                item["headers"] as JsonObject ?? new JsonObject(),
                item["payload"]));
        }

        using var client = CreateRabbitClient(options);
        var baseUrl = RabbitBaseUrl(options);
        var vhost = Uri.EscapeDataString(RabbitVhost(options));
        var exchange = options.Get("exchange", "codex.demo");
        var escapedExchange = Uri.EscapeDataString(exchange);
        var exchangeUrl = $"{baseUrl}/api/exchanges/{vhost}/{escapedExchange}";
        var exchangeDeclaration = new JsonObject
        {
            ["type"] = "direct",
            ["auto_delete"] = false,
            ["durable"] = true,
            ["internal"] = false,
            ["arguments"] = new JsonObject(),
        };
        await SendJsonAsync(client, HttpMethod.Put, exchangeUrl, exchangeDeclaration, allowEmptyResponse: true);

        var queues = messages
            .Select(message => message.Queue)
            .Distinct(StringComparer.Ordinal)
            .OrderBy(name => name)
            .ToArray();

        foreach (var queue in queues)
        {
            var queueUrl = BuildQueueUrl(options, queue);
            var declaration = new JsonObject
            {
                ["auto_delete"] = false,
                ["durable"] = true,
                ["arguments"] = new JsonObject(),
            };
            await SendJsonAsync(client, HttpMethod.Put, queueUrl, declaration, allowEmptyResponse: true);

            if (options.HasFlag("purge"))
            {
                await SendJsonAsync(client, HttpMethod.Delete, queueUrl + "/contents", body: null, allowEmptyResponse: true);
            }
        }

        var bindings = messages
            .Select(message => new QueueBinding(
                message.Queue,
                string.IsNullOrWhiteSpace(message.RoutingKey) ? message.Queue : message.RoutingKey!))
            .Distinct()
            .OrderBy(binding => binding.Queue, StringComparer.Ordinal)
            .ThenBy(binding => binding.RoutingKey, StringComparer.Ordinal)
            .ToArray();

        foreach (var bindingItem in bindings)
        {
            var bindingUrl = $"{baseUrl}/api/bindings/{vhost}/e/{escapedExchange}/q/{Uri.EscapeDataString(bindingItem.Queue)}";
            var binding = new JsonObject
            {
                ["routing_key"] = bindingItem.RoutingKey,
                ["arguments"] = new JsonObject(),
            };
            await SendJsonAsync(client, HttpMethod.Post, bindingUrl, binding, allowEmptyResponse: true);
        }

        var publishUrl = $"{exchangeUrl}/publish";
        var published = 0;

        foreach (var message in messages)
        {
            var properties = new JsonObject
            {
                ["content_type"] = "application/json",
                ["delivery_mode"] = 2,
                ["message_id"] = message.MessageId,
                ["headers"] = CloneNode(message.Headers),
            };
            var payloadText = message.Payload?.ToJsonString(CompactJson) ?? "null";
            var request = new JsonObject
            {
                ["properties"] = properties,
                ["routing_key"] = string.IsNullOrWhiteSpace(message.RoutingKey) ? message.Queue : message.RoutingKey,
                ["payload"] = payloadText,
                ["payload_encoding"] = "string",
            };

            var response = await SendJsonAsync(client, HttpMethod.Post, publishUrl, request) as JsonObject;
            if (response?["routed"]?.GetValue<bool>() != true)
            {
                throw new InvalidOperationException($"RabbitMQ не маршрутизировал сообщение {message.MessageId} в очередь {message.Queue}.");
            }

            published++;
        }

        Console.WriteLine($"Опубликовано сообщений: {published}; exchange: {exchange}; очереди: {string.Join(", ", queues)}");
        return 0;
    }

    private static HttpClient CreateRabbitClient(CommandLineOptions options)
    {
        var username = options.Get("username", Environment.GetEnvironmentVariable("RABBITMQ_USERNAME") ?? "demo");
        var password = options.Get("password", Environment.GetEnvironmentVariable("RABBITMQ_PASSWORD") ?? "demo");
        var auth = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{username}:{password}"));

        var client = new HttpClient { Timeout = TimeSpan.FromSeconds(15) };
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", auth);
        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        return client;
    }

    private static async Task<JsonNode?> SendJsonAsync(
        HttpClient client,
        HttpMethod method,
        string url,
        JsonNode? body,
        bool allowEmptyResponse = false)
    {
        using var request = new HttpRequestMessage(method, url);
        if (body is not null)
        {
            request.Content = JsonContent.Create(body, options: CompactJson);
        }

        using var response = await client.SendAsync(request);
        var responseText = await response.Content.ReadAsStringAsync();
        if (!response.IsSuccessStatusCode)
        {
            throw new HttpRequestException(
                $"RabbitMQ API вернул {(int)response.StatusCode} {response.ReasonPhrase}: {responseText}");
        }

        if (string.IsNullOrWhiteSpace(responseText))
        {
            return allowEmptyResponse ? null : throw new InvalidDataException("RabbitMQ API вернул пустой ответ.");
        }

        return JsonNode.Parse(responseText);
    }

    private static string BuildQueueUrl(CommandLineOptions options, string queue)
    {
        var baseUrl = RabbitBaseUrl(options);
        var vhost = Uri.EscapeDataString(RabbitVhost(options));
        return $"{baseUrl}/api/queues/{vhost}/{Uri.EscapeDataString(queue)}";
    }

    private static async Task<int?> GetQueueMessageCountAsync(
        HttpClient client,
        CommandLineOptions options,
        string queue)
    {
        var response = await SendJsonAsync(
            client,
            HttpMethod.Get,
            BuildQueueUrl(options, queue),
            body: null) as JsonObject;

        return GetInt(response?["messages"]);
    }

    private static async Task<int?> WaitForQueueMessageCountAsync(
        HttpClient client,
        CommandLineOptions options,
        string queue,
        int? expectedMinimum)
    {
        int? latest = null;

        // Статистика Management API может обновляться не мгновенно,
        // поэтому даём брокеру несколько секунд показать возвращённые сообщения.
        for (var attempt = 0; attempt < 12; attempt++)
        {
            latest = await GetQueueMessageCountAsync(client, options, queue);
            if (expectedMinimum is null
                || latest is { } current && current >= expectedMinimum.Value)
            {
                return latest;
            }

            await Task.Delay(TimeSpan.FromMilliseconds(500));
        }

        return latest;
    }

    private static string RabbitBaseUrl(CommandLineOptions options) =>
        options.Get("base-url", Environment.GetEnvironmentVariable("RABBITMQ_API_URL") ?? "http://localhost:15672")
            .TrimEnd('/');

    private static string RabbitVhost(CommandLineOptions options) =>
        options.Get("vhost", Environment.GetEnvironmentVariable("RABBITMQ_VHOST") ?? "/");

    private static JsonNode DecodeApiPayload(JsonObject item)
    {
        var payload = GetString(item["payload"]) ?? string.Empty;
        if (string.Equals(GetString(item["payload_encoding"]), "base64", StringComparison.OrdinalIgnoreCase))
        {
            payload = Encoding.UTF8.GetString(Convert.FromBase64String(payload));
        }

        try
        {
            return JsonNode.Parse(payload) ?? JsonValue.Create(payload)!;
        }
        catch (JsonException)
        {
            return JsonValue.Create(payload)!;
        }
    }

    private static HashSet<string> CandidateIds(MessageEnvelope message)
    {
        var candidates = new[]
        {
            message.MessageId,
            GetString(message.Headers["x-message-id"]),
            GetPayloadString(message.Payload, "message_id"),
            GetPayloadString(message.Payload, "id"),
            GetPayloadString(message.Payload, "event_id"),
        };

        return candidates
            .Where(value => !string.IsNullOrWhiteSpace(value))
            .Select(value => value!)
            .ToHashSet(StringComparer.Ordinal);
    }

    private static string DescriptionOf(MessageEnvelope message)
    {
        if (message.Payload is JsonObject payload)
        {
            foreach (var key in new[] { "description", "message", "detail", "reason" })
            {
                var value = GetString(payload[key]);
                if (!string.IsNullOrWhiteSpace(value))
                {
                    return value;
                }
            }
        }

        var text = GetString(message.Payload);
        return string.IsNullOrWhiteSpace(text) ? "Описание в сообщении отсутствует." : text;
    }

    private static string? GetPayloadString(JsonNode? payload, string key) =>
        payload is JsonObject payloadObject ? GetString(payloadObject[key]) : null;

    private static string? GetString(JsonNode? node)
    {
        if (node is null)
        {
            return null;
        }

        if (node is JsonValue value && value.TryGetValue<string>(out var text))
        {
            return text;
        }

        return node.ToJsonString(CompactJson);
    }

    private static int? GetInt(JsonNode? node)
    {
        if (node is not JsonValue value)
        {
            return null;
        }

        if (value.TryGetValue<int>(out var intValue))
        {
            return intValue;
        }

        if (value.TryGetValue<long>(out var longValue)
            && longValue is >= int.MinValue and <= int.MaxValue)
        {
            return (int)longValue;
        }

        return null;
    }

    private static void PrintPreservationStatus(MessageLoadResult loadResult)
    {
        if (!loadResult.MessagesRequeued)
        {
            return;
        }

        Console.WriteLine("Режим:        сообщения возвращены в очередь (ack_requeue_true)");

        if (loadResult.QueueMessagesBefore is { } before
            && loadResult.QueueMessagesAfter is { } after)
        {
            Console.WriteLine($"В очереди:    до {before}, после {after}");
        }
        else
        {
            Console.WriteLine("В очереди:    не удалось получить счётчики до и после просмотра");
        }
    }

    private static JsonNode CloneNode(JsonNode node) =>
        JsonNode.Parse(node.ToJsonString(CompactJson)) ?? new JsonObject();

    private static void PrintUsage()
    {
        Console.Error.WriteLine("Использование:");
        Console.Error.WriteLine("  RabbitMessageTools find --source mock --file data/rabbit_messages.jsonl --queue order.events --id MSG-7F31A9");
        Console.Error.WriteLine("  RabbitMessageTools find --source live --yes-live --queue order.events --id MSG-7F31A9 --count 100");
        Console.Error.WriteLine("  RabbitMessageTools seed --file data/rabbit_messages.jsonl --exchange codex.demo --purge");
    }

    private sealed record QueueBinding(string Queue, string RoutingKey);

    private sealed record MessageEnvelope(
        string Queue,
        string? MessageId,
        string? RoutingKey,
        JsonObject Headers,
        JsonNode? Payload);

    private sealed record MessageLoadResult(
        IReadOnlyList<MessageEnvelope> Messages,
        bool MessagesRequeued,
        int? QueueMessagesBefore,
        int? QueueMessagesAfter);

    private sealed class CommandLineOptions
    {
        private readonly Dictionary<string, string?> _values;

        private CommandLineOptions(Dictionary<string, string?> values) => _values = values;

        public static CommandLineOptions Parse(IReadOnlyList<string> args)
        {
            var values = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase);
            for (var index = 0; index < args.Count; index++)
            {
                var token = args[index];
                if (!token.StartsWith("--", StringComparison.Ordinal))
                {
                    throw new ArgumentException($"Неожиданный аргумент: {token}");
                }

                var name = token[2..];
                if (index + 1 >= args.Count || args[index + 1].StartsWith("--", StringComparison.Ordinal))
                {
                    values[name] = null;
                    continue;
                }

                values[name] = args[++index];
            }

            return new CommandLineOptions(values);
        }

        public bool HasFlag(string name) => _values.ContainsKey(name);

        public string Required(string name)
        {
            if (!_values.TryGetValue(name, out var value) || string.IsNullOrWhiteSpace(value))
            {
                throw new ArgumentException($"Обязательный параметр --{name} не указан.");
            }

            return value;
        }

        public string Get(string name, string defaultValue) =>
            _values.TryGetValue(name, out var value) && !string.IsNullOrWhiteSpace(value) ? value : defaultValue;

        public int GetInt(string name, int defaultValue)
        {
            var raw = Get(name, defaultValue.ToString(System.Globalization.CultureInfo.InvariantCulture));
            return int.TryParse(raw, out var value)
                ? value
                : throw new ArgumentException($"Параметр --{name} должен быть целым числом.");
        }
    }
}
