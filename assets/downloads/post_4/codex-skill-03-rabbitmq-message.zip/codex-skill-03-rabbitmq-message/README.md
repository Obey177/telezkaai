# Skill 3: найти сообщение в RabbitMQ по ID

Самостоятельный пример навыка Codex, который находит сообщение по `message_id` и выводит его `description`. Для безопасного показа можно искать в локальном JSONL; для локального стенда архив содержит отдельный RabbitMQ Compose.

## Состав

- `.agents/skills/rabbit-message-by-id/SKILL.md` — инструкция навыка;
- `.agents/skills/rabbit-message-by-id/scripts/` — C# / .NET 10 / C# 14-утилита;
- `data/rabbit_messages.jsonl` — демонстрационные сообщения;
- `docker-compose.yml` — отдельный RabbitMQ с Management UI.

## Требования

Требуется .NET 10 SDK. Для live-демонстрации дополнительно нужен Docker Compose.

## Безопасная демонстрация без Docker

```bash
dotnet run --project .agents/skills/rabbit-message-by-id/scripts/RabbitMessageTools.csproj -- \
  find --source mock \
  --file data/rabbit_messages.jsonl \
  --queue order.events \
  --id MSG-7F31A9
```

## Демонстрация с локальным RabbitMQ

Запустите брокер:

```bash
docker compose up -d --wait
```

Management UI: `http://localhost:15672`, логин `demo`, пароль `demo`.

Создайте exchange и очереди, затем опубликуйте тестовые сообщения:

```bash
dotnet run --project .agents/skills/rabbit-message-by-id/scripts/RabbitMessageTools.csproj -- \
  seed --file data/rabbit_messages.jsonl --exchange codex.demo --purge
```

Ограниченный live-поиск:

```bash
dotnet run --project .agents/skills/rabbit-message-by-id/scripts/RabbitMessageTools.csproj -- \
  find --source live --yes-live \
  --queue order.events --id MSG-7F31A9 --count 20
```

## Запрос для Codex

```text
$rabbit-message-by-id

Найди сообщение MSG-7F31A9 в очереди order.events
и выведи его description. Сообщение не удаляй:
после проверки оно должно остаться в очереди.
```

Live-режим диагностический: он получает ограниченную выборку сообщений через Management API с `ack_requeue_true`, поэтому сообщения не удаляются и после просмотра остаются в очереди. Утилита также показывает количество сообщений до и после запроса; на локальном стенде ожидается одинаковое значение. Такой поиск не подходит для регулярного обхода производственной очереди.
