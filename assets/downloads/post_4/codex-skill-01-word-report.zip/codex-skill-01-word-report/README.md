# Skill 1: Word-отчёт по шаблону

Этот самостоятельный пример показывает понятный обычному человеку сценарий: Codex получает Excel-файл, следует сохранённым правилам, заполняет Word-шаблон и формулирует выводы. Отдельного C#-приложения здесь нет.

## Что находится в архиве

- `.agents/skills/weekly-operations-report/SKILL.md` — инструкция навыка;
- `data/sales_by_day.xlsx` — исходные показатели за 14 дней;
- `data/sales_by_day.csv` — резервная машиночитаемая копия тех же данных;
- `assets/weekly_operations_report_template.docx` внутри папки skill — Word-шаблон;
- `references/` — правила расчётов и описание полей шаблона;
- `output/weekly_operations_report_example.docx` — пример готового результата.

## Запрос для демонстрации

```text
$weekly-operations-report

Подготовь недельный операционный отчёт по файлу data/sales_by_day.xlsx.
Используй корпоративный Word-шаблон из skill и сохрани результат
в output/weekly_operations_report.docx.
```

Codex должен сравнить две недели, заметить всплеск ошибок 10 июля, отделить факт от предположения и предложить, что проверить.
