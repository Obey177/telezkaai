# Skill 2: узнать состояние записи в PostgreSQL

Самостоятельный пример навыка Codex, который получает ID записи, запускает read-only C#-коннектор на Entity Framework Core и возвращает понятный статус вместе с историей изменений.

## Состав

- `.agents/skills/db-record-status/SKILL.md` — инструкция навыка;
- `.agents/skills/db-record-status/scripts/` — C# / .NET 10 / C# 14 / EF Core 10-коннектор;
- `infra/postgres/init/001_schema_seed_and_reader.sql` — схема, тестовые записи и роль только для чтения;
- `docker-compose.yml` — отдельный PostgreSQL только для этого примера.

## Запуск

Требуются Docker Compose и .NET 10 SDK.

```bash
docker compose up -d --wait
```

```bash
dotnet run --project .agents/skills/db-record-status/scripts/DbRecordStatus.csproj -- \
  --id ORD-1042
```

Для JSON-ответа добавьте `--json`. Проект таргетирует `net10.0`, а PostgreSQL-провайдер — `Npgsql.EntityFrameworkCore.PostgreSQL` 10.0.3.

## Запрос для Codex

```text
$db-record-status

Проверь, что сейчас происходит с записью ORD-1042.
Покажи текущий статус, описание, ответственного и историю изменений.
Ничего в базе не изменяй.
```

По умолчанию коннектор подключается как `codex_reader`. У этой роли есть только `SELECT`, включён режим `default_transaction_read_only`, а `DbContext` запрещает `SaveChanges`.

## Остановка и полный сброс

```bash
docker compose down
```

```bash
docker compose down -v
```
