namespace CodexSkillsDemo.DbRecordStatus.Data.Entities;

public sealed class RecordEntity
{
    public string Id { get; set; } = string.Empty;

    public string RecordType { get; set; } = string.Empty;

    public string Status { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;

    public string? Owner { get; set; }

    public DateTimeOffset CreatedAt { get; set; }

    public DateTimeOffset UpdatedAt { get; set; }

    public string MetadataJson { get; set; } = "{}";

    public ICollection<RecordStatusHistoryEntity> History { get; set; } = new List<RecordStatusHistoryEntity>();
}
