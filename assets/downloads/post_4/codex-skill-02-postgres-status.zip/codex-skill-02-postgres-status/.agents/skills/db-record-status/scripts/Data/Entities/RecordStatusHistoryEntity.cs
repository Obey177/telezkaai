namespace CodexSkillsDemo.DbRecordStatus.Data.Entities;

public sealed class RecordStatusHistoryEntity
{
    public long HistoryId { get; set; }

    public string RecordId { get; set; } = string.Empty;

    public string Status { get; set; } = string.Empty;

    public DateTimeOffset ChangedAt { get; set; }

    public string? Comment { get; set; }

    public RecordEntity Record { get; set; } = null!;
}
