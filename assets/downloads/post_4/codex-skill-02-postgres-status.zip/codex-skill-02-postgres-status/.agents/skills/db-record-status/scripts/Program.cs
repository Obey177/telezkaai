using System.Globalization;
using System.Text.Encodings.Web;
using System.Text.Json;
using CodexSkillsDemo.DbRecordStatus.Data;
using CodexSkillsDemo.DbRecordStatus.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Npgsql;

namespace CodexSkillsDemo.DbRecordStatus;

internal static class Program
{
    private const string DefaultConnectionString =
        "Host=localhost;Port=5432;Database=codex_demo;Username=codex_reader;Password=codex_reader;Application Name=codex-skill-demo";

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    };

    public static async Task<int> Main(string[] args)
    {
        try
        {
            var commandLine = CommandLineOptions.Parse(args);
            var recordId = commandLine.Required("id");
            var connectionString = ResolveConnectionString(commandLine);

            var optionsBuilder = new DbContextOptionsBuilder<RecordsDbContext>()
                .UseNpgsql(
                    connectionString,
                    providerOptions => providerOptions.EnableRetryOnFailure(
                        maxRetryCount: 3,
                        maxRetryDelay: TimeSpan.FromSeconds(2),
                        errorCodesToAdd: null))
                .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
                .EnableSensitiveDataLogging(false);

            if (commandLine.HasFlag("show-sql"))
            {
                optionsBuilder.LogTo(Console.Error.WriteLine, LogLevel.Information);
            }

            await using var dbContext = new RecordsDbContext(optionsBuilder.Options);
            var reader = new RecordStatusReader(dbContext);
            var record = await reader.FindAsync(recordId);

            if (record is null)
            {
                Console.WriteLine($"Запись {recordId} не найдена.");
                return 2;
            }

            if (commandLine.HasFlag("json"))
            {
                Console.WriteLine(JsonSerializer.Serialize(record, JsonOptions));
            }
            else
            {
                PrintHumanReadable(record);
            }

            return 0;
        }
        catch (NpgsqlException exception)
        {
            Console.Error.WriteLine(
                "Не удалось прочитать PostgreSQL. Проверьте, что `docker compose up -d --wait postgres` завершился успешно и строка подключения верна.");
            Console.Error.WriteLine($"Техническая причина: {exception.Message}");
            return 3;
        }
        catch (Exception exception)
        {
            Console.Error.WriteLine($"Ошибка: {exception.Message}");
            return 1;
        }
    }

    private static string ResolveConnectionString(CommandLineOptions commandLine)
    {
        var fromArgument = commandLine.Get("connection");
        if (!string.IsNullOrWhiteSpace(fromArgument))
        {
            return fromArgument;
        }

        return Environment.GetEnvironmentVariable("POSTGRES_CONNECTION_STRING")
            ?? Environment.GetEnvironmentVariable("ConnectionStrings__RecordsDb")
            ?? DefaultConnectionString;
    }

    private static void PrintHumanReadable(RecordStatusResult record)
    {
        var culture = CultureInfo.GetCultureInfo("ru-RU");

        Console.WriteLine($"Запись:        {record.Id}");
        Console.WriteLine($"Тип:           {record.RecordType}");
        Console.WriteLine($"Статус:        {record.Status}");
        Console.WriteLine($"Описание:      {record.Description}");
        Console.WriteLine($"Ответственный: {record.Owner ?? "—"}");
        Console.WriteLine($"Обновлена:     {record.UpdatedAt.ToString("dd.MM.yyyy HH:mm:ss zzz", culture)}");
        Console.WriteLine();
        Console.WriteLine("История статусов:");

        foreach (var item in record.History)
        {
            var comment = string.IsNullOrWhiteSpace(item.Comment)
                ? string.Empty
                : $" — {item.Comment}";
            Console.WriteLine(
                $"  {item.ChangedAt.ToString("dd.MM.yyyy HH:mm:ss zzz", culture)}  {item.Status}{comment}");
        }
    }

    private sealed class CommandLineOptions
    {
        private readonly Dictionary<string, string?> values;

        private CommandLineOptions(Dictionary<string, string?> values) => this.values = values;

        public static CommandLineOptions Parse(IReadOnlyList<string> args)
        {
            var values = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase);

            for (var index = 0; index < args.Count; index++)
            {
                var token = args[index];
                if (!token.StartsWith("--", StringComparison.Ordinal))
                {
                    throw new ArgumentException($"Неожиданный аргумент: {token}");
                }

                var name = token[2..];
                if (index + 1 >= args.Count || args[index + 1].StartsWith("--", StringComparison.Ordinal))
                {
                    values[name] = null;
                    continue;
                }

                values[name] = args[++index];
            }

            return new CommandLineOptions(values);
        }

        public bool HasFlag(string name) => values.ContainsKey(name);

        public string Required(string name)
        {
            var value = Get(name);
            return string.IsNullOrWhiteSpace(value)
                ? throw new ArgumentException($"Обязательный параметр --{name} не указан.")
                : value;
        }

        public string? Get(string name) =>
            values.TryGetValue(name, out var value) ? value : null;
    }
}
