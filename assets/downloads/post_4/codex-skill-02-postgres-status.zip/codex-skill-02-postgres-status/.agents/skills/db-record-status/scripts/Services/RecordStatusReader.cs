using System.Text.Json;
using CodexSkillsDemo.DbRecordStatus.Data;
using Microsoft.EntityFrameworkCore;

namespace CodexSkillsDemo.DbRecordStatus.Services;

public sealed class RecordStatusReader(RecordsDbContext dbContext)
{
    public async Task<RecordStatusResult?> FindAsync(
        string recordId,
        CancellationToken cancellationToken = default)
    {
        var record = await dbContext.Records
            .AsNoTracking()
            .SingleOrDefaultAsync(item => item.Id == recordId, cancellationToken);

        if (record is null)
        {
            return null;
        }

        var history = await dbContext.RecordStatusHistory
            .AsNoTracking()
            .Where(item => item.RecordId == recordId)
            .OrderBy(item => item.ChangedAt)
            .Select(item => new RecordStatusHistoryResult(
                item.Status,
                item.ChangedAt,
                item.Comment))
            .ToListAsync(cancellationToken);

        using var metadataDocument = JsonDocument.Parse(record.MetadataJson);
        var result = new RecordStatusResult(
            record.Id,
            record.RecordType,
            record.Status,
            record.Description,
            record.Owner,
            record.CreatedAt,
            record.UpdatedAt,
            metadataDocument.RootElement.Clone(),
            history);

        return result;
    }
}
