using System.Text.Json;

namespace CodexSkillsDemo.DbRecordStatus.Services;

public sealed record RecordStatusResult(
    string Id,
    string RecordType,
    string Status,
    string Description,
    string? Owner,
    DateTimeOffset CreatedAt,
    DateTimeOffset UpdatedAt,
    JsonElement Metadata,
    IReadOnlyList<RecordStatusHistoryResult> History);

public sealed record RecordStatusHistoryResult(
    string Status,
    DateTimeOffset ChangedAt,
    string? Comment);
