using CodexSkillsDemo.DbRecordStatus.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace CodexSkillsDemo.DbRecordStatus.Data;

public sealed class RecordsDbContext(DbContextOptions<RecordsDbContext> options) : DbContext(options)
{
    public DbSet<RecordEntity> Records => Set<RecordEntity>();

    public DbSet<RecordStatusHistoryEntity> RecordStatusHistory => Set<RecordStatusHistoryEntity>();

    public override int SaveChanges(bool acceptAllChangesOnSuccess) =>
        throw new NotSupportedException("Этот EF Core-коннектор работает только в режиме чтения.");

    public override Task<int> SaveChangesAsync(
        bool acceptAllChangesOnSuccess,
        CancellationToken cancellationToken = default) =>
        throw new NotSupportedException("Этот EF Core-коннектор работает только в режиме чтения.");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        var record = modelBuilder.Entity<RecordEntity>();
        record.ToTable("records");
        record.HasKey(item => item.Id);
        record.Property(item => item.Id).HasColumnName("id");
        record.Property(item => item.RecordType).HasColumnName("record_type").IsRequired();
        record.Property(item => item.Status).HasColumnName("status").IsRequired();
        record.Property(item => item.Description).HasColumnName("description").IsRequired();
        record.Property(item => item.Owner).HasColumnName("owner");
        record.Property(item => item.CreatedAt).HasColumnName("created_at");
        record.Property(item => item.UpdatedAt).HasColumnName("updated_at");
        record.Property(item => item.MetadataJson)
            .HasColumnName("metadata_json")
            .HasColumnType("jsonb")
            .IsRequired();

        var history = modelBuilder.Entity<RecordStatusHistoryEntity>();
        history.ToTable("record_status_history");
        history.HasKey(item => item.HistoryId);
        history.Property(item => item.HistoryId).HasColumnName("history_id");
        history.Property(item => item.RecordId).HasColumnName("record_id").IsRequired();
        history.Property(item => item.Status).HasColumnName("status").IsRequired();
        history.Property(item => item.ChangedAt).HasColumnName("changed_at");
        history.Property(item => item.Comment).HasColumnName("comment");
        history.HasIndex(item => new { item.RecordId, item.ChangedAt })
            .HasDatabaseName("ix_record_status_history_record_changed");

        record.HasMany(item => item.History)
            .WithOne(item => item.Record)
            .HasForeignKey(item => item.RecordId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}
